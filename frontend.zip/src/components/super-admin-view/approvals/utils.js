export const approvalTabs = [
  {
    id: "companies",
    name: "Companies",
    icon: null,
  },
  {
    id: "jobTrainings",
    name: "Job/Trainings",
    icon: null,
  },
  {
    id: "trainers",
    name: "Trainers",
    icon: null,
  },
  {
    id: "recruiters",
    name: "Recruiters",
    icon: null,
  },
  // {
  //   id: "candidates",
  //   name: "Candidates",
  //   icon: null,
  // },
];

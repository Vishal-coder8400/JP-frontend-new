import RecruitersTab from "../../../common/recruiters/RecruitersTab";

const RecruitersTabApprovals = () => {
  return <RecruitersTab context="approvals" />;
};

export default RecruitersTabApprovals;

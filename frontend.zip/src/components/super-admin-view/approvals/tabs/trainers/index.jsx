import { TrainersTab } from "../../../common/trainers";

const TrainersTabApprovals = () => {
  return <TrainersTab context="approvals" />;
};

export default TrainersTabApprovals;

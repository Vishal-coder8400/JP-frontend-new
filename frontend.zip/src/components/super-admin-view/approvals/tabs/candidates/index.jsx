import CandidatesTab from "../../../common/candidates/CandidatesTab";

const CandidatesTabApprovals = () => {
  return <CandidatesTab context="approvals" />;
};

export default CandidatesTabApprovals;

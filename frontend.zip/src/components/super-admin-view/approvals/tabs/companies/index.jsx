import CompaniesTab from "../../../common/companies/CompaniesTab";

const CompaniesTabApprovals = () => {
  return <CompaniesTab context="approvals" />;
};

export default CompaniesTabApprovals;

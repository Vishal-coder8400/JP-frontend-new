import FinalSetUpCorporate from "../../components/corporate-view/final-setup";
const FinalSetup = () => {
  return (
    <div className="w-full">
      <FinalSetUpCorporate />
    </div>
  );
};

export default FinalSetup;

import SuperAdminDatabase from "@/components/super-admin-view/database";

const SuperAdminDatabasePage = () => {
  return <SuperAdminDatabase />;
};

export default SuperAdminDatabasePage;

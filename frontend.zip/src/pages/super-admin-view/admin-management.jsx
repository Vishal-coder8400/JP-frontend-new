import SuperAdminAdminManagement from "@/components/super-admin-view/admin-management";

const SuperAdminAdminManagementPage = () => {
  return <SuperAdminAdminManagement />;
};

export default SuperAdminAdminManagementPage;

import SuperAdminMasterData from "@/components/super-admin-view/master-data";

const SuperAdminMasterDataPage = () => {
  return (
    <div>
      <SuperAdminMasterData />
    </div>
  );
};

export default SuperAdminMasterDataPage;

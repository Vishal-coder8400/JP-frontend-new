import JobsAndTrainings from "@/components/super-admin-view/jobs-and-trainings";

const SuperAdminJobsAndTrainingsPage = () => {
  return <JobsAndTrainings />;
};

export default SuperAdminJobsAndTrainingsPage;

import Approvals from "@/components/super-admin-view/approvals";

const SuperAdminApprovals = () => {
  return (
    <div>
      <Approvals />
    </div>
  );
};

export default SuperAdminApprovals;
